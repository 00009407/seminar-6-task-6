word = 'banana'
print()
print(word.count("a"))
print()